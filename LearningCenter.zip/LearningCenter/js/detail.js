// -------------  details descriptions ----------------

const opt1 = document.getElementById("sl-title1");
const opt2 = document.getElementById("sl-title2");
const opt3 = document.getElementById("sl-title3");

const optpara1 = document.getElementById("desc-para");
const optpara2 = document.getElementById("modules-para");
const optpara3 = document.getElementById("outcome-para");

	opt1.onclick = function(){
		optpara1.style.display = "inline-block";		
		optpara2.style.display = "none";
		optpara3.style.display = "none";		
		opt1.style.borderBottom = "3px solid #1ebed6";
		opt2.style.borderBottom = "none";
		opt3.style.borderBottom ="none";
	}

	opt2.onclick = function(){
		optpara1.style.display = "none";
		optpara2.style.display = "block";
		optpara3.style.display = "none";	
		opt1.style.borderBottom = "none";
		opt2.style.borderBottom = "3px solid #1ebed6";
		opt3.style.borderBottom ="none";
	}

	opt3.onclick = function(){
		optpara1.style.display = "none";
		optpara2.style.display = "none";
		optpara3.style.display = "block";	
		opt1.style.borderBottom = "none";
		opt2.style.borderBottom = "none";
		opt3.style.borderBottom ="3px solid #1ebed6";
	}



// --------------------  modules --------------------

const mod1 = document.getElementById("module-title1");
const mod2 = document.getElementById("module-title2");
const mod3 = document.getElementById("module-title3");

const modcont1 = document.getElementById("module-contents1");
const modcont2 = document.getElementById("module-contents2");
const modcont3 = document.getElementById("module-contents3");

	var icon;

mod1.onclick = function(){

	icon = mod1.querySelector('i.fa');
  	icon.classList.toggle('rotate');

	if(modcont1.style.display === "block"){
		modcont1.style.display = "none";
	}
	else{
		modcont1.style.display = "block";
	}	
}

mod2.onclick = function(){

	icon = mod2.querySelector('i.fa');
  	icon.classList.toggle('rotate');

	if(modcont2.style.display === "block"){
		modcont2.style.display = "none";
	}
	else{
		modcont2.style.display = "block";
	}
}

mod3.onclick = function(){

	icon = mod3.querySelector('i.fa');
  	icon.classList.toggle('rotate');

	if(modcont3.style.display === "block"){
		modcont3.style.display = "none";
	}
	else{
		modcont3.style.display = "block";
	}
}


// ----------------------- login/sign up -------------


	let enroll = document.getElementById("enroll");
	let startnow = document.getElementById("start-now");
	let showdiv = document.getElementById("login");
	let cross = document.getElementById("cross");

	enroll.onclick = function(){
		showdiv.style.display="block";
	}

	startnow.onclick = function(){
		showdiv.style.display="block";
	}

	cross.onclick = function(){
		showdiv.style.display = "none";
	}


	let optlog = document.getElementById("opt-log");
	let optsig = document.getElementById("opt-sig");
	let titlelog = document.getElementById("log-title");
	let titlesig = document.getElementById("sig-title");
	let logmsg = document.getElementById("log-body");
	let sigmsg = document.getElementById("sig-body");

	optlog.onclick = function(){
		titlesig.style.display = "none";
		sigmsg.style.display = "none";

		titlelog.style.display = "block";
		logmsg.style.display = "flex";

		optlog.style.background = "#e3dada";
		optsig.style.background = "#aeb0b5";
	}

	optsig.onclick = function(){
		titlelog.style.display = "none";
		logmsg.style.display = "none";

		titlesig.style.display = "block";
		sigmsg.style.display = "flex";

		optsig.style.background = "#e3dada";
		optlog.style.background = "#aeb0b5";
	}

