const counters = document.querySelectorAll('.counter');

counters.forEach((counter) => {
	counter.innerText = '0';

	const updateCounter = ()=>{
		const target = +counter.getAttribute('data-target');
		const c = +counter.innerText;

		const increment = target / 700;

		if (c < target){
			counter.innerText = `${Math.ceil(c + increment)}`;
			setTimeout(updateCounter,1);
		}else{
			counter.innerText = target;
		}
	};
	updateCounter();
});

let btn1 = document.querySelector('#btn1');
let btn2 = document.querySelector('#btn2');
let btn3 = document.querySelector('#btn3');
let btn4 = document.querySelector('#btn4');
let btn5 = document.querySelector('#btn5');
let btn6 = document.querySelector('#btn6');
let paragraph = document.querySelector('#content');

btn1.addEventListener('click', () => {
	paragraph.innerText = 'I\'m glad "I chose this place to take the course. The center is located in a nice area which is very close to the metro station. As for the course I was satisfied as well. Most of the inputs were informative and teaching practice feedback was very detailed. I\'d especially like to mention that the tutors were extremely supportive throughout all of the course. There were a few administrative problems related to equipment but they were usually solved soon after a problem had been reported. Overall, I definitely recommend Grade to anyone who is going to take this course in Ukraine.';
});
btn2.addEventListener('click', () => {
	paragraph.innerText = 'I was informed that it was going to be very intensive and challenging, but I hadn\'t expected that it would be that demanding, stressful and sometimes exhausting. I felt it was going to be great, although I didn\'t even think that it would turn out to be so amazing, involving and educational. I learnt a great deal more than at the university. That\'s true, indeed. I\'m so lucky to have met such knowledgeable, sophisticated and wise tutors. I\'m very thankful to all my colleagues who were friendly, cheerful and helpful';
});

btn3.addEventListener('click', () => {
	paragraph.innerText = 'Amazing professional and friendly atmosphere, helpful and cheerful staff, challenging but manageable programme and schedule, wonderful tutors.';
});

btn4.addEventListener('click', () => {
	paragraph.innerText = 'Everything was fine, I am completely satisfied. If I had a chance I would come to get DELTA. The tutors were amazing, friendly enough and rather tolerant, the administration reacted quickly, we had all the stuff we needed. Also a big thank you word to the guard always saying goodbye and good morning.';
});

btn5.addEventListener('click', () => {
	paragraph.innerText = 'I would like to say that it was undoubtedly intensive and interesting month of my studying. The CELTA course is the very first step of my teaching career. It is the best thing I have ever done but also the hardest that I ever had to do. I should admit that I did a lot of improvement and got a great experience thanks to our amazing tutors, Amir and Missy. They completely changed my views on teaching process. This course helped me to realize that nothing is impossible. It opened my eyes to a world full of possibilities for my future! Many thanks for an inspiring course with the best tutors ever!!!';
});

btn6.addEventListener('click', () => {
	paragraph.innerText = 'The course was extremely tough and intensive, though really effective. Tutors were very helpful. Overall it\'s an amazing experience for every teacher, and I had a great time there with my peers!!!';
});

$(document).on('click', 'button', function(){
	$(this).addClass('active').siblings().removeClass('active')
})