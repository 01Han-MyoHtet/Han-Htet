// ---------------- slide course ------------------

var slideIndex =1;
	showSlides(slideIndex);

	function plusSlides(n){
		showSlides(slideIndex += n);
	}

	function currentSlide(n){
		showSlides(slideIndex = n);
	}

	function showSlides(n){
		var i;
		var slides = document.getElementsByClassName("slideshow-container");
		var dots = document.getElementsByClassName("dot");

		if( n>slides.length ){
			slideIndex =1;
		}

		if( n<1 ){
			slideIndex = slides.length
		}

		for( i=0; i<slides.length; i++ ){
			slides[i].style.display = "none";
		}

		for( i=0; i<dots.length; i++ ){
			dots[i].className = dots[i].className.replace(" active","");
		}

		slides[slideIndex-1].style.display ="block";
		dots[slideIndex-1].className +=" active";
			
	}




// ----------------- data count ------------------------

var container = document.querySelector('.count-container');
var hasEntered = false;

window.addEventListener('scroll', (e) => {
	var shouldAnimate = (window.scrollY + window.innerHeight) >= container.offsetTop;

	if(shouldAnimate && !hasEntered){
		hasEntered = true;

		$('.counter').each(function () {
			$(this).prop('Counter',0).animate({
 				Counter: $(this).text()
 			}, {
 				duration: 4000,
 				easing: 'swing',
 				step: function (now) {
 					$(this).text(Math.ceil(now));
 				}
 			});
		});
	}
})


// --------------------------
