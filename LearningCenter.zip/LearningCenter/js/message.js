let msgbtn = document.getElementById("msg-btn");
let msgbox = document.getElementById("msg-box");

	msgbtn.onclick = function(){
		if(msgbox.style.display === "none"){
			msgbox.style.display = "block";
		}
		else{
			msgbox.style.display = "none";
		}
	}